"""Portal publico de consulta de chamados do GLPI."""
import json
import os
import re
import secrets
import threading
import time
from collections import defaultdict, deque

from fastapi import Depends, FastAPI, HTTPException, Request, Response
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

import glpi
from usuarios import ErroUsuario, Usuarios

DATA_DIR = os.environ.get("DATA_DIR", "/data")
ARQ_CONFIG = os.path.join(DATA_DIR, "config.json")
STATIC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
COOKIE = "portal_admin"
COOKIE_TEC = "portal_tecnico"
HORAS_SESSAO = int(os.environ.get("SESSION_HOURS", "8"))

CONFIG_PADRAO = {
    # conexao com o GLPI
    "glpi_url": "", "app_token": "", "user_token": "", "verify_ssl": False, "timeout": 30, "retries": 2,
    # aparencia
    "titulo": "Consulta de chamados",
    "mensagem": "Digite o número do chamado para acompanhar o andamento do seu atendimento.",
    # o que o portal mostra
    "exigir_email": False,
    "mostrar_descricao": True,
    "mostrar_historico": True,
    "mostrar_tecnico": True,
    "mostrar_nomes": False,
    "mostrar_sla": False,
    # protecao contra varredura de numeros
    "limite_por_minuto": 10,
    # area de atendimento: perfis do GLPI que podem entrar com usuario e senha do AD
    "atendimento_ativo": True,
    "perfis_atendimento": "Technician",
}
CAMPOS_BOOL = ("verify_ssl", "exigir_email", "mostrar_descricao", "mostrar_historico",
               "mostrar_tecnico", "mostrar_nomes", "mostrar_sla", "atendimento_ativo")

app = FastAPI(title="Portal de consulta GLPI", docs_url=None, redoc_url=None, openapi_url=None)
app.mount("/static", StaticFiles(directory=STATIC), name="static")
conexao = glpi.Conexao()
usuarios = Usuarios(DATA_DIR)
usuarios.garantir_admin_inicial(os.environ.get("PORTAL_ADMIN", "admin"), os.environ.get("PORTAL_SENHA", ""))


# ------------------------------------------------------------------ configuracao
def ler_config():
    cfg = dict(CONFIG_PADRAO)
    try:
        with open(ARQ_CONFIG, encoding="utf-8") as f:
            cfg.update(json.load(f))
    except (FileNotFoundError, json.JSONDecodeError):
        pass
    return cfg


def gravar_config(cfg):
    os.makedirs(DATA_DIR, exist_ok=True)
    tmp = ARQ_CONFIG + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    os.chmod(tmp, 0o600)
    os.replace(tmp, ARQ_CONFIG)


def mesclar(novo):
    cfg = ler_config()
    for campo in ("glpi_url", "titulo", "mensagem", "perfis_atendimento"):
        if campo in novo:
            cfg[campo] = str(novo[campo] or "").strip()[:500]
    cfg["glpi_url"] = glpi.normalizar_url(cfg["glpi_url"])
    for campo in ("app_token", "user_token"):  # em branco = manter o atual
        valor = str(novo.get(campo) or "").strip()
        if valor:
            cfg[campo] = valor
    if novo.get("limpar_app_token"):
        cfg["app_token"] = ""
    for campo in CAMPOS_BOOL:
        if campo in novo:
            cfg[campo] = bool(novo[campo])
    for campo, minimo, maximo in (("timeout", 5, 300), ("retries", 1, 5), ("limite_por_minuto", 1, 120)):
        if campo in novo:
            try:
                cfg[campo] = min(maximo, max(minimo, int(novo[campo])))
            except (TypeError, ValueError):
                pass
    return cfg


# ------------------------------------------------------------------ limite de consultas por IP
CONSULTAS = defaultdict(deque)
TRAVA_LIMITE = threading.Lock()


def ip_cliente(request: Request):
    return request.client.host if request.client else "?"


def verificar_limite(ip, limite, tipo="consulta"):
    agora = time.time()
    with TRAVA_LIMITE:
        fila = CONSULTAS[(tipo, ip)]
        while fila and agora - fila[0] > 60:
            fila.popleft()
        if len(fila) >= limite:
            return False
        fila.append(agora)
        if len(CONSULTAS) > 5000:  # limpeza de enderecos antigos
            for chave in [k for k, v in CONSULTAS.items() if not v or agora - v[-1] > 60]:
                CONSULTAS.pop(chave, None)
        return True


# ------------------------------------------------------------------ paginas
@app.get("/")
def pagina_publica():
    return FileResponse(os.path.join(STATIC, "index.html"))


@app.get("/admin")
def pagina_admin():
    return FileResponse(os.path.join(STATIC, "admin.html"))


# ------------------------------------------------------------------ API publica
@app.get("/api/portal")
def api_portal():
    cfg = ler_config()
    return {"titulo": cfg["titulo"], "mensagem": cfg["mensagem"], "exigir_email": cfg["exigir_email"],
            "configurado": bool(cfg["glpi_url"] and cfg["user_token"])}


@app.post("/api/consulta")
def api_consulta(dados: dict, request: Request):
    cfg = ler_config()
    numero = re.sub(r"\D", "", str(dados.get("numero", "")))
    if not numero or len(numero) > 15:
        raise HTTPException(400, "Informe o número do chamado (somente números).")
    if not verificar_limite(ip_cliente(request), cfg["limite_por_minuto"]):
        raise HTTPException(429, "Muitas consultas em pouco tempo. Aguarde um minuto e tente novamente.")
    if cfg["exigir_email"] and not str(dados.get("email", "")).strip():
        raise HTTPException(400, "Informe o e-mail usado na abertura do chamado.")
    try:
        resultado = conexao.consultar(cfg, int(numero), dados.get("email"))
    except glpi.GlpiError:
        raise HTTPException(503, "A consulta está indisponível no momento. Tente novamente em alguns minutos.")
    if not resultado:
        # mesma resposta para "nao existe" e "e-mail nao confere": nao revela quais numeros existem
        msg = "Chamado não encontrado. Confira o número"
        msg += " e o e-mail informados." if cfg["exigir_email"] else " informado."
        raise HTTPException(404, msg)
    return resultado


# ------------------------------------------------------------------ area administrativa
def admin_atual(request: Request):
    u = usuarios.ler_sessao(request.cookies.get(COOKIE, ""))
    if not u or u["role"] != "admin":
        raise HTTPException(401, "Entre com o usuário administrador.")
    return u


# ---- sessoes dos tecnicos (em memoria: reiniciar o portal pede login de novo)
SESSOES = {}
TRAVA_SESSOES = threading.Lock()


def perfis_atendimento(cfg):
    return [p.strip() for p in str(cfg.get("perfis_atendimento") or "").split(",") if p.strip()]


def tecnico_atual(request: Request):
    sid = request.cookies.get(COOKIE_TEC, "")
    with TRAVA_SESSOES:
        s = SESSOES.get(sid)
        if s and s["expira"] < time.time():
            SESSOES.pop(sid, None)
            s = None
    if not s:
        raise HTTPException(401, "Sessão encerrada. Entre novamente.")
    return {**s, "sid": sid}


def encerrar_sessao(sid):
    with TRAVA_SESSOES:
        s = SESSOES.pop(sid, None)
    if s:
        glpi.logout_tecnico(ler_config(), s["token"])


@app.post("/api/admin/login")
def api_login(dados: dict, request: Request, response: Response):
    login = str(dados.get("username", "")).strip()
    senha = str(dados.get("password", ""))
    if not verificar_limite(ip_cliente(request), 10, "login"):
        raise HTTPException(429, "Muitas tentativas de login. Aguarde um minuto.")
    # 1) administrador local do portal (configuracoes)
    u = usuarios.autenticar(login, senha)
    if u and u["role"] == "admin":
        response.set_cookie(COOKIE, usuarios.criar_sessao(u["username"]), httponly=True, samesite="strict", secure=request.url.scheme == "https",
                            max_age=HORAS_SESSAO * 3600)
        return {"tipo": "admin", "nome": u["name"]}
    # 2) tecnico: o GLPI confere usuario e senha no AD/LDAP configurado nele
    cfg = ler_config()
    if not cfg["atendimento_ativo"] or not login or not senha:
        time.sleep(1)
        raise HTTPException(401, "Usuário ou senha incorretos.")
    try:
        t = glpi.login_tecnico(cfg, login, senha, perfis_atendimento(cfg))
    except glpi.AcessoNegado:
        raise HTTPException(403, "Seu usuário não tem um perfil liberado para o atendimento neste portal.")
    except glpi.GlpiError as e:
        raise HTTPException(503, str(e))
    if not t:
        time.sleep(1)
        raise HTTPException(401, "Usuário ou senha incorretos.")
    sid = secrets.token_urlsafe(32)
    with TRAVA_SESSOES:
        SESSOES[sid] = {**t, "expira": time.time() + HORAS_SESSAO * 3600}
    response.set_cookie(COOKIE_TEC, sid, httponly=True, samesite="strict", secure=request.url.scheme == "https", max_age=HORAS_SESSAO * 3600)
    return {"tipo": "tecnico", "nome": t["nome"]}


@app.post("/api/admin/logout")
def api_logout(request: Request, response: Response):
    encerrar_sessao(request.cookies.get(COOKIE_TEC, ""))
    response.delete_cookie(COOKIE)
    response.delete_cookie(COOKIE_TEC)
    return {"ok": True}


@app.get("/api/admin/me")
def api_me(request: Request):
    u = usuarios.ler_sessao(request.cookies.get(COOKIE, ""))
    if u and u["role"] == "admin":
        return {"tipo": "admin", "nome": u["name"]}
    t = tecnico_atual(request)
    return {"tipo": "tecnico", "nome": t["nome"], "uid": t["uid"], "perfil": t["perfil"]}


@app.post("/api/admin/senha")
def api_senha(dados: dict, u: dict = Depends(admin_atual)):
    if not usuarios.autenticar(u["username"], str(dados.get("atual", ""))):
        raise HTTPException(400, "A senha atual está incorreta.")
    try:
        usuarios.alterar(u["username"], senha=str(dados.get("nova", "")))
    except ErroUsuario as e:
        raise HTTPException(400, str(e))
    return {"ok": True}


@app.get("/api/admin/config")
def api_config(_: dict = Depends(admin_atual)):
    cfg = ler_config()
    publico = {k: v for k, v in cfg.items() if k not in ("app_token", "user_token")}
    publico["app_token_set"] = bool(cfg["app_token"])
    publico["user_token_set"] = bool(cfg["user_token"])
    return publico


@app.post("/api/admin/config")
def api_config_salvar(novo: dict, u: dict = Depends(admin_atual)):
    gravar_config(mesclar(novo))
    return api_config(u)


@app.post("/api/admin/teste")
def api_teste(novo: dict, _: dict = Depends(admin_atual)):
    teste = glpi.Conexao()  # conexao separada: nao derruba a sessao usada pelo portal
    try:
        return {"ok": True, "message": teste.testar(mesclar(novo))}
    except glpi.GlpiError as e:
        return {"ok": False, "message": str(e)}


# ------------------------------------------------------------------ area de atendimento (tecnicos)
def glpi_do_tecnico(funcao, t, *args):
    """Executa uma chamada com a sessao do tecnico; se ela expirou no GLPI, pede novo login."""
    try:
        return funcao(ler_config(), t["token"], *args)
    except glpi.SessaoExpirada:
        encerrar_sessao(t["sid"])
        raise HTTPException(401, "Sua sessão no GLPI expirou. Entre novamente.")
    except glpi.GlpiError as e:
        raise HTTPException(503, str(e))


@app.get("/api/atendimento/opcoes")
def api_opcoes(t: dict = Depends(tecnico_atual)):
    cfg = ler_config()
    try:
        tecnicos = conexao.tecnicos(cfg, perfis_atendimento(cfg))
    except glpi.GlpiError:
        tecnicos = []
    if not any(x["id"] == t["uid"] for x in tecnicos):
        tecnicos = [{"id": t["uid"], "nome": t["nome"]}] + tecnicos
    return {"eu": t["uid"], "tecnicos": tecnicos,
            "situacoes": [{"id": k, "nome": v[1]} for k, v in glpi.SITUACOES.items()]}


@app.get("/api/atendimento/chamados")
def api_chamados(tecnico: int = 0, situacao: str = "abertos", pagina: int = 1, t: dict = Depends(tecnico_atual)):
    return glpi_do_tecnico(glpi.listar_chamados, t, tecnico, situacao, max(1, pagina))


@app.get("/api/atendimento/chamado/{tid}")
def api_chamado(tid: int, t: dict = Depends(tecnico_atual)):
    d = glpi_do_tecnico(glpi.detalhar_chamado, t, tid)
    if not d:
        raise HTTPException(404, "Chamado não encontrado ou sem permissão para você.")
    return d


@app.post("/api/atendimento/chamado/{tid}/responder")
def api_responder(tid: int, dados: dict, t: dict = Depends(tecnico_atual)):
    texto = str(dados.get("texto") or "").strip()
    acao = dados.get("acao") if dados.get("acao") in ("resposta", "pendente", "solucao") else "resposta"
    if len(texto) < 3:
        raise HTTPException(400, "Escreva a resposta antes de enviar.")
    msg = glpi_do_tecnico(glpi.responder_chamado, t, tid, texto, acao, bool(dados.get("privado")))
    return {"message": msg, "chamado": glpi_do_tecnico(glpi.detalhar_chamado, t, tid)}


@app.post("/api/atendimento/chamado/{tid}/assumir")
def api_assumir(tid: int, t: dict = Depends(tecnico_atual)):
    msg = glpi_do_tecnico(glpi.atribuir_a_mim, t, tid, t["uid"])
    return {"message": msg, "chamado": glpi_do_tecnico(glpi.detalhar_chamado, t, tid)}
