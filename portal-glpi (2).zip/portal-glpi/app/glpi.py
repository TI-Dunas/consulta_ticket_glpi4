"""Consulta de chamados na API REST do GLPI, reaproveitando a sessao entre consultas."""
import html
import re
import threading
import time
from datetime import datetime

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

STATUS = {
    1: ("Novo", "Recebido pela equipe de suporte, aguardando atendimento."),
    2: ("Em atendimento", "Um técnico está trabalhando no seu chamado."),
    3: ("Em atendimento (planejado)", "O atendimento está agendado."),
    4: ("Pendente", "Aguardando uma informação ou retorno para continuar."),
    5: ("Solucionado", "A solução foi registrada e aguarda a sua aprovação."),
    6: ("Fechado", "Chamado encerrado."),
}


class GlpiError(Exception):
    """Falha de comunicacao ou de configuracao (nao e 'chamado inexistente')."""


def parse_dt(valor):
    if not valor:
        return None
    try:
        return datetime.strptime(str(valor)[:19], "%Y-%m-%d %H:%M:%S")
    except ValueError:
        return None


def fmt(dt):
    return dt.strftime("%d/%m/%Y %H:%M") if dt else None


def normalizar_url(url):
    url = (url or "").strip().rstrip("/")
    if url and "apirest.php" not in url:
        url += "/apirest.php"
    return url


def texto_limpo(conteudo, limite=None):
    """HTML do GLPI -> texto puro (o portal nunca exibe HTML vindo do GLPI)."""
    t = str(conteudo or "")
    for _ in range(2):  # o GLPI costuma gravar o HTML ja codificado (&lt;p&gt;)
        t = html.unescape(t)
    t = re.sub(r"<(script|style)[^>]*>.*?</\1\s*>", "", t, flags=re.I | re.S)
    t = re.sub(r"<\s*(br|/p|/div|/li|/tr|/h\d)\s*/?>", "\n", t, flags=re.I)
    t = re.sub(r"<li[^>]*>", "• ", t, flags=re.I)
    t = re.sub(r"<[^>]+>", "", t)
    t = re.sub(r"[ \t\xa0]+", " ", t)
    t = re.sub(r"\n\s*\n\s*\n+", "\n\n", t).strip()
    if limite and len(t) > limite:
        t = t[:limite].rstrip() + "…"
    return t


class Conexao:
    """Mantem uma sessao da API aberta e refaz o login quando ela expira."""

    def __init__(self):
        self.trava = threading.Lock()
        self.token = None
        self.chave = None
        self.nomes = {}

    def _base(self, cfg):
        h = {"Content-Type": "application/json"}
        if cfg.get("app_token"):
            h["App-Token"] = cfg["app_token"]
        return h

    def _http(self, cfg, metodo, url, **kw):
        tentativas = max(1, int(cfg.get("retries") or 2))
        timeout = max(5, int(cfg.get("timeout") or 30))
        for n in range(1, tentativas + 1):
            try:
                return requests.request(metodo, url, verify=bool(cfg.get("verify_ssl")), timeout=timeout, **kw)
            except requests.exceptions.SSLError:
                raise GlpiError("Erro de certificado SSL ao acessar o GLPI. Desmarque 'Verificar certificado SSL'.")
            except (requests.exceptions.Timeout, requests.exceptions.ConnectionError):
                if n == tentativas:
                    raise GlpiError("O GLPI não respondeu. Tente novamente em alguns minutos.")
                time.sleep(2 * n)

    def _sessao(self, cfg, forcar=False):
        url = normalizar_url(cfg.get("glpi_url"))
        if not url or not cfg.get("user_token"):
            raise GlpiError("O portal ainda não foi configurado.")
        chave = (url, cfg.get("app_token"), cfg.get("user_token"), bool(cfg.get("verify_ssl")))
        with self.trava:
            if self.token and self.chave == chave and not forcar:
                return url, self.token
            h = self._base(cfg)
            h["Authorization"] = f"user_token {cfg['user_token']}"
            r = self._http(cfg, "GET", f"{url}/initSession", headers=h)
            if r.status_code != 200:
                self.token = None
                raise GlpiError(f"O GLPI recusou o login da API (HTTP {r.status_code}): {r.text[:200]}")
            self.token, self.chave = r.json()["session_token"], chave
            self.nomes = {}
            try:  # visao de todas as entidades do usuario da API
                self._http(cfg, "POST", f"{url}/changeActiveEntities",
                           headers={**self._base(cfg), "Session-Token": self.token},
                           json={"entities_id": 0, "is_recursive": True})
            except GlpiError:
                pass
            return url, self.token

    def get(self, cfg, caminho, params=None):
        url, token = self._sessao(cfg)
        r = self._http(cfg, "GET", f"{url}/{caminho}", headers={**self._base(cfg), "Session-Token": token}, params=params)
        if r.status_code == 401 and "SESSION" in r.text.upper():  # sessao expirou: novo login e repete
            url, token = self._sessao(cfg, forcar=True)
            r = self._http(cfg, "GET", f"{url}/{caminho}", headers={**self._base(cfg), "Session-Token": token}, params=params)
        if r.status_code >= 500:
            raise GlpiError("O GLPI apresentou um erro interno. Tente novamente em alguns minutos.")
        return r

    def lista(self, cfg, caminho):
        r = self.get(cfg, caminho)
        if r.status_code not in (200, 206):
            return []
        dados = r.json()
        return dados if isinstance(dados, list) else []

    def nome(self, cfg, uid):
        if not uid:
            return None
        if uid not in self.nomes:
            r = self.get(cfg, f"User/{uid}")
            if r.status_code == 200:
                u = r.json()
                self.nomes[uid] = " ".join(x for x in [u.get("firstname"), u.get("realname")] if x) or u.get("name")
            else:
                self.nomes[uid] = None
        return self.nomes[uid]

    def tecnicos(self, cfg, perfis_permitidos):
        """Usuarios com os perfis de atendimento (para o filtro por tecnico). Cache de 10 minutos."""
        cache = getattr(self, "_cache_tec", None)
        if cache and time.time() - cache[0] < 600:
            return cache[1]
        alvo = {p.strip().lower() for p in perfis_permitidos if p.strip()}
        perfis = {p["id"] for p in self.lista(cfg, "Profile?range=0-999") if str(p.get("name", "")).strip().lower() in alvo}
        ids, inicio = set(), 0
        while perfis:
            lote = self.lista(cfg, f"Profile_User?range={inicio}-{inicio + 999}")
            ids |= {pu.get("users_id") for pu in lote if pu.get("profiles_id") in perfis}
            if len(lote) < 1000:
                break
            inicio += 1000
        lista = []
        for uid in ids:
            r = self.get(cfg, f"User/{uid}")
            if r.status_code == 200:
                u = r.json()
                if u.get("is_active", 1) and not u.get("is_deleted"):
                    nome = " ".join(x for x in [u.get("firstname"), u.get("realname")] if x) or u.get("name")
                    lista.append({"id": uid, "nome": nome})
        lista.sort(key=lambda x: x["nome"].lower())
        self._cache_tec = (time.time(), lista)
        return lista

    def testar(self, cfg):
        self._sessao(cfg, forcar=True)
        r = self.get(cfg, "getFullSession")
        if r.status_code != 200:
            raise GlpiError(f"Login feito, mas a sessão não pôde ser lida (HTTP {r.status_code}).")
        perfil = (r.json().get("session") or {}).get("glpiactiveprofile", {}).get("name", "?")
        return f"Conexão OK. Usuário da API conectado com o perfil '{perfil}'."

    # ------------------------------------------------------------ consulta do chamado
    def consultar(self, cfg, numero, email=None):
        """Retorna os dados publicos do chamado, ou None se nao existir / nao puder ser exibido."""
        r = self.get(cfg, f"Ticket/{numero}", {"expand_dropdowns": "true"})
        if r.status_code != 200:
            return None
        t = r.json()
        if not isinstance(t, dict) or t.get("is_deleted"):
            return None

        atores = self.lista(cfg, f"Ticket/{numero}/Ticket_User")
        requerentes = {a.get("users_id") for a in atores if a.get("type") == 1 and a.get("users_id")}
        tecnicos = [a.get("users_id") for a in atores if a.get("type") == 2 and a.get("users_id")]

        if cfg.get("exigir_email"):
            informado = (email or "").strip().lower()
            if not informado:
                return None
            validos = {str(a.get("alternative_email") or "").strip().lower() for a in atores if a.get("type") == 1}
            for uid in requerentes:
                for e in self.lista(cfg, f"User/{uid}/UserEmail"):
                    validos.add(str(e.get("email") or "").strip().lower())
            if informado not in validos:
                return None

        mostrar_nomes = bool(cfg.get("mostrar_nomes"))
        status = int(t.get("status") or 0)
        nome_status, explicacao = STATUS.get(status, ("Desconhecido", ""))
        prazo = parse_dt(t.get("time_to_resolve"))
        solucao = parse_dt(t.get("solvedate"))
        agora = datetime.now()

        dados = {
            "numero": t.get("id"),
            "titulo": texto_limpo(t.get("name"), 200),
            "status": {"codigo": status, "nome": nome_status, "explicacao": explicacao},
            "abertura": fmt(parse_dt(t.get("date"))),
            "atualizacao": fmt(parse_dt(t.get("date_mod"))),
            "solucao": fmt(solucao),
            "fechamento": fmt(parse_dt(t.get("closedate"))),
            "categoria": texto_limpo(t.get("itilcategories_id")) if t.get("itilcategories_id") not in (0, "0", None) else None,
        }
        if cfg.get("mostrar_tecnico"):
            nomes = [self.nome(cfg, u) for u in tecnicos]
            dados["tecnicos"] = [n for n in nomes if n] or None
        if cfg.get("mostrar_sla") and prazo:
            if status in (5, 6):
                situacao = "Cumprido" if solucao and solucao <= prazo else "Fora do prazo"
            elif status == 4:
                situacao = "Pausado enquanto pendente"
            else:
                situacao = "Dentro do prazo" if agora <= prazo else "Prazo excedido"
            dados["sla"] = {"prazo": fmt(prazo), "situacao": situacao}
        if cfg.get("mostrar_descricao"):
            dados["descricao"] = texto_limpo(t.get("content"), 4000)

        if cfg.get("mostrar_historico"):
            eventos = [{"tipo": "abertura", "data": parse_dt(t.get("date")), "autor": None,
                        "texto": "Chamado aberto."}]
            for fu in self.lista(cfg, f"Ticket/{numero}/ITILFollowup"):
                if fu.get("is_private"):
                    continue  # nunca exibe acompanhamentos privados
                do_cliente = fu.get("users_id") in requerentes
                autor = (self.nome(cfg, fu.get("users_id")) if mostrar_nomes else None) or \
                        ("Solicitante" if do_cliente else "Equipe de suporte")
                eventos.append({"tipo": "cliente" if do_cliente else "suporte",
                                "data": parse_dt(fu.get("date_creation") or fu.get("date")),
                                "autor": autor, "texto": texto_limpo(fu.get("content"), 3000)})
            for s in self.lista(cfg, f"Ticket/{numero}/ITILSolution"):
                autor = (self.nome(cfg, s.get("users_id")) if mostrar_nomes else None) or "Equipe de suporte"
                eventos.append({"tipo": "solucao", "data": parse_dt(s.get("date_creation")), "autor": autor,
                                "texto": texto_limpo(s.get("content"), 3000)})
                if s.get("status") == 3 and parse_dt(s.get("date_approval")):
                    eventos.append({"tipo": "aprovada", "data": parse_dt(s.get("date_approval")), "autor": None,
                                    "texto": "Solução aprovada pelo solicitante."})
                elif s.get("status") == 4 and parse_dt(s.get("date_approval")):
                    eventos.append({"tipo": "recusada", "data": parse_dt(s.get("date_approval")), "autor": None,
                                    "texto": "Solução recusada pelo solicitante. O atendimento foi retomado."})
            if parse_dt(t.get("closedate")):
                eventos.append({"tipo": "fechamento", "data": parse_dt(t.get("closedate")), "autor": None,
                                "texto": "Chamado fechado."})
            eventos = [e for e in eventos if e["data"]]
            eventos.sort(key=lambda e: e["data"])
            for e in eventos:
                e["data"] = fmt(e["data"])
            dados["historico"] = eventos
        return dados


# ====================================================================== atendimento (sessao do tecnico)
class SessaoExpirada(Exception):
    """A sessao do tecnico no GLPI expirou ou foi encerrada."""


class AcessoNegado(Exception):
    """Login correto, mas o usuario nao tem um perfil permitido no portal."""


def _cab(cfg, token=None):
    h = {"Content-Type": "application/json"}
    if cfg.get("app_token"):
        h["App-Token"] = cfg["app_token"]
    if token:
        h["Session-Token"] = token
    return h


def _req(cfg, metodo, caminho, token=None, extra=None, **kw):
    url = normalizar_url(cfg.get("glpi_url"))
    if not url:
        raise GlpiError("O portal ainda não foi configurado.")
    h = _cab(cfg, token)
    if extra:
        h.update(extra)
    try:
        r = requests.request(metodo, f"{url}/{caminho}", headers=h, verify=bool(cfg.get("verify_ssl")),
                             timeout=max(5, int(cfg.get("timeout") or 30)), **kw)
    except requests.exceptions.SSLError:
        raise GlpiError("Erro de certificado SSL ao acessar o GLPI.")
    except requests.exceptions.RequestException:
        raise GlpiError("O GLPI não respondeu. Tente novamente em alguns minutos.")
    if token and r.status_code == 401 and "SESSION" in r.text.upper():
        raise SessaoExpirada()
    if r.status_code >= 500:
        raise GlpiError("O GLPI apresentou um erro interno. Tente novamente.")
    return r


def login_tecnico(cfg, login, senha, perfis_permitidos):
    """Login no GLPI com usuario e senha (o GLPI autentica no AD/LDAP configurado nele)."""
    import base64
    cred = base64.b64encode(f"{login}:{senha}".encode()).decode()
    r = _req(cfg, "GET", "initSession", extra={"Authorization": f"Basic {cred}"})
    if r.status_code != 200:
        texto = r.text.upper()
        if "LOGIN_WITH_CREDENTIALS_DISABLED" in texto:
            raise GlpiError("O GLPI não permite login pela API com usuário e senha. Ative em "
                            "Configurar > Geral > API > 'Habilitar login com credenciais'.")
        if "APP_TOKEN" in texto:
            raise GlpiError("O App Token configurado no portal foi recusado pelo GLPI.")
        if "NOT_ALLOWED_IP" in texto:
            raise GlpiError("O GLPI não aceita chamadas da API vindas do IP do portal (cliente da API).")
        return None  # usuario ou senha incorretos
    token = r.json()["session_token"]
    try:
        perfis = _req(cfg, "GET", "getMyProfiles", token).json().get("myprofiles", [])
        alvo = {p.strip().lower() for p in perfis_permitidos if p.strip()}
        escolhido = next((p for p in perfis if str(p.get("name", "")).strip().lower() in alvo), None)
        if not escolhido:
            raise AcessoNegado()
        _req(cfg, "POST", "changeActiveProfile", token, json={"profiles_id": escolhido["id"]})
        _req(cfg, "POST", "changeActiveEntities", token, json={"entities_id": 0, "is_recursive": True})
        sess = (_req(cfg, "GET", "getFullSession", token).json() or {}).get("session", {})
        nome = " ".join(x for x in [sess.get("glpifirstname"), sess.get("glpirealname")] if x) or sess.get("glpiname") or login
        return {"token": token, "uid": int(sess.get("glpiID") or 0), "login": sess.get("glpiname") or login,
                "nome": nome, "perfil": escolhido.get("name")}
    except Exception:
        try:
            _req(cfg, "GET", "killSession", token)
        except Exception:  # noqa: BLE001
            pass
        raise


def logout_tecnico(cfg, token):
    try:
        _req(cfg, "GET", "killSession", token)
    except Exception:  # noqa: BLE001
        pass


SITUACOES = {
    "abertos": ("notold", "Em aberto (novo, em atendimento, pendente)"),
    "pendentes": (4, "Pendentes"),
    "atendimento": (2, "Em atendimento"),
    "novos": (1, "Novos"),
    "solucionados": (5, "Solucionados (aguardando aprovação)"),
}


def listar_chamados(cfg, token, tecnico_id, situacao, pagina, por_pagina=20):
    valor = SITUACOES.get(situacao, SITUACOES["abertos"])[0]
    inicio = max(0, (pagina - 1) * por_pagina)
    params = {"criteria[0][field]": 12, "criteria[0][searchtype]": "equals", "criteria[0][value]": valor,
              "forcedisplay[0]": 2, "sort": 19, "order": "DESC", "range": f"{inicio}-{inicio + por_pagina - 1}"}
    if tecnico_id:
        params.update({"criteria[1][link]": "AND", "criteria[1][field]": 5,
                       "criteria[1][searchtype]": "equals", "criteria[1][value]": tecnico_id})
    r = _req(cfg, "GET", "search/Ticket", token, params=params)
    if r.status_code == 400 and "RANGE_EXCEED" in r.text.upper():
        return {"total": 0, "itens": []}
    if r.status_code not in (200, 206):
        raise GlpiError(f"Não foi possível listar os chamados (HTTP {r.status_code}).")
    dados = r.json()
    agora = datetime.now()
    itens = []
    for linha in dados.get("data") or []:
        tid = int(linha.get("2") or 0)
        rt = _req(cfg, "GET", f"Ticket/{tid}", token, params={"expand_dropdowns": "true"})
        if rt.status_code != 200:
            continue
        t = rt.json()
        status = int(t.get("status") or 0)
        prazo = parse_dt(t.get("time_to_resolve"))
        espera = parse_dt(t.get("begin_waiting_date")) if status == 4 else None
        itens.append({
            "id": tid, "titulo": texto_limpo(t.get("name"), 140), "status": status,
            "nome_status": STATUS.get(status, ("?", ""))[0],
            "abertura": fmt(parse_dt(t.get("date"))), "atualizacao": fmt(parse_dt(t.get("date_mod"))),
            "prazo": fmt(prazo), "atrasado": bool(prazo and status not in (4, 5, 6) and agora > prazo),
            "pendente_desde": fmt(espera),
            "localizacao": nome_dropdown(t.get("locations_id")),
        })
    return {"total": int(dados.get("totalcount") or 0), "itens": itens}


def nome_dropdown(valor):
    """Nome de lista suspensa vindo com expand_dropdowns (0 ou vazio = nao preenchido)."""
    return texto_limpo(valor) if valor not in (0, "0", None, "") else None


def detalhar_chamado(cfg, token, tid):
    r = _req(cfg, "GET", f"Ticket/{tid}", token, params={"expand_dropdowns": "true"})
    if r.status_code != 200:
        return None
    t = r.json()
    atores = _req(cfg, "GET", f"Ticket/{tid}/Ticket_User", token).json()
    atores = atores if isinstance(atores, list) else []
    nomes = {}

    def nome(uid):
        if uid not in nomes:
            ru = _req(cfg, "GET", f"User/{uid}", token)
            u = ru.json() if ru.status_code == 200 else {}
            nomes[uid] = " ".join(x for x in [u.get("firstname"), u.get("realname")] if x) or u.get("name") or f"Usuário {uid}"
        return nomes[uid]

    requerentes = [a["users_id"] for a in atores if a.get("type") == 1 and a.get("users_id")]
    tecnicos = [a["users_id"] for a in atores if a.get("type") == 2 and a.get("users_id")]
    status = int(t.get("status") or 0)
    eventos = [{"tipo": "abertura", "data": parse_dt(t.get("date")), "autor": None, "texto": "Chamado aberto.", "privado": False}]
    def lista(caminho):
        rr = _req(cfg, "GET", caminho, token)
        d = rr.json() if rr.status_code in (200, 206) else []
        return d if isinstance(d, list) else []
    for fu in lista(f"Ticket/{tid}/ITILFollowup"):
        eventos.append({"tipo": "cliente" if fu.get("users_id") in requerentes else "suporte",
                        "data": parse_dt(fu.get("date_creation") or fu.get("date")),
                        "autor": nome(fu.get("users_id")) if fu.get("users_id") else "Sistema",
                        "texto": texto_limpo(fu.get("content"), 5000), "privado": bool(fu.get("is_private"))})
    for s in lista(f"Ticket/{tid}/ITILSolution"):
        eventos.append({"tipo": "solucao", "data": parse_dt(s.get("date_creation")),
                        "autor": nome(s.get("users_id")) if s.get("users_id") else "Sistema",
                        "texto": texto_limpo(s.get("content"), 5000), "privado": False})
        if s.get("status") in (3, 4) and parse_dt(s.get("date_approval")):
            eventos.append({"tipo": "aprovada" if s.get("status") == 3 else "recusada",
                            "data": parse_dt(s.get("date_approval")), "autor": None, "privado": False,
                            "texto": "Solução aprovada pelo solicitante." if s.get("status") == 3
                            else "Solução recusada pelo solicitante."})
    eventos = sorted([e for e in eventos if e["data"]], key=lambda e: e["data"])
    for e in eventos:
        e["data"] = fmt(e["data"])
    return {
        "id": t.get("id"), "titulo": texto_limpo(t.get("name"), 200), "status": status,
        "nome_status": STATUS.get(status, ("?", ""))[0],
        "abertura": fmt(parse_dt(t.get("date"))), "atualizacao": fmt(parse_dt(t.get("date_mod"))),
        "prazo": fmt(parse_dt(t.get("time_to_resolve"))),
        "categoria": nome_dropdown(t.get("itilcategories_id")),
        "localizacao": nome_dropdown(t.get("locations_id")),
        "requerentes": [nome(u) for u in requerentes], "tecnicos": [nome(u) for u in tecnicos],
        "tecnicos_ids": tecnicos,
        "descricao": texto_limpo(t.get("content"), 8000), "historico": eventos,
        "pode_responder": status not in (6,),
    }


def responder_chamado(cfg, token, tid, texto, acao, privado):
    """acao: 'resposta' (acompanhamento), 'pendente' (acompanhamento + pendencia) ou 'solucao'."""
    conteudo = html.escape(texto.strip()).replace("\n", "<br>")
    if acao == "solucao":
        r = _req(cfg, "POST", "ITILSolution", token,
                 json={"input": {"itemtype": "Ticket", "items_id": tid, "content": conteudo}})
        if r.status_code not in (200, 201):
            raise GlpiError(f"O GLPI não aceitou a solução: {r.text[:200]}")
        return "Solução registrada. O chamado ficou Solucionado e aguarda a aprovação do solicitante."
    entrada = {"itemtype": "Ticket", "items_id": tid, "content": conteudo,
               "is_private": 1 if (privado and acao == "resposta") else 0}
    if acao == "pendente":
        entrada["pending"] = 1  # mesma alavanca de "Pendente" do formulario do GLPI 10
    r = _req(cfg, "POST", "ITILFollowup", token, json={"input": entrada})
    if r.status_code not in (200, 201):
        raise GlpiError(f"O GLPI não aceitou a resposta: {r.text[:200]}")
    if acao == "pendente":
        st = _req(cfg, "GET", f"Ticket/{tid}", token).json()
        if int(st.get("status") or 0) != 4:  # versoes sem a alavanca na API: muda o status direto
            r2 = _req(cfg, "PUT", f"Ticket/{tid}", token, json={"input": {"id": tid, "status": 4}})
            if r2.status_code not in (200, 201):
                return "Resposta enviada, mas o GLPI não permitiu colocar o chamado em pendência."
        return "Resposta enviada e chamado colocado em Pendente, aguardando o retorno do cliente."
    return "Acompanhamento privado registrado." if entrada["is_private"] else "Resposta enviada ao solicitante."


def atribuir_a_mim(cfg, token, tid, uid):
    """Adiciona o tecnico logado como 'Atribuido' (mesmo efeito do botao 'Associar a mim mesmo' do GLPI)."""
    atores = _req(cfg, "GET", f"Ticket/{tid}/Ticket_User", token).json()
    if isinstance(atores, list) and any(a.get("type") == 2 and a.get("users_id") == uid for a in atores):
        return "Você já está atribuído a este chamado."
    r = _req(cfg, "POST", "Ticket_User", token, json={"input": {"tickets_id": tid, "users_id": uid, "type": 2}})
    if r.status_code not in (200, 201):
        raise GlpiError(f"O GLPI não permitiu a atribuição: {r.text[:200]}")
    return "Chamado associado a você."
