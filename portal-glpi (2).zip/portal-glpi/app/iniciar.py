"""Inicia o portal em HTTPS.

1. Se nao existir certificado em /data/certs, gera um autoassinado para os enderecos de PORTAL_HOSTS.
2. Sobe um redirecionador HTTP (porta PORTA_HTTP) que manda tudo para https://...:PORTA_HTTPS_PUBLICA.
3. Sobe o portal (uvicorn) em HTTPS na porta PORTA_HTTPS.

Para usar um certificado da empresa, coloque cert.pem (com a cadeia) e key.pem em /data/certs
e reinicie o conteiner.
"""
import datetime
import ipaddress
import os
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import uvicorn

DATA_DIR = os.environ.get("DATA_DIR", "/data")
PASTA_CERT = os.path.join(DATA_DIR, "certs")
CERT = os.path.join(PASTA_CERT, "cert.pem")
CHAVE = os.path.join(PASTA_CERT, "key.pem")
PORTA_HTTPS = int(os.environ.get("PORTA_HTTPS", "8443"))
PORTA_HTTP = int(os.environ.get("PORTA_HTTP", "8090"))
PORTA_PUBLICA = os.environ.get("PORTA_HTTPS_PUBLICA", str(PORTA_HTTPS))
HOSTS = [h.strip() for h in os.environ.get("PORTAL_HOSTS", "localhost").split(",") if h.strip()]


def gerar_certificado():
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID

    chave = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    nomes = []
    for h in HOSTS + ["localhost"]:
        try:
            nomes.append(x509.IPAddress(ipaddress.ip_address(h)))
        except ValueError:
            nomes.append(x509.DNSName(h))
    nome = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, HOSTS[0]),
                      x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Portal de Consulta GLPI")])
    agora = datetime.datetime.now(datetime.timezone.utc)
    cert = (x509.CertificateBuilder()
            .subject_name(nome).issuer_name(nome).public_key(chave.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(agora - datetime.timedelta(minutes=5))
            .not_valid_after(agora + datetime.timedelta(days=825))
            .add_extension(x509.SubjectAlternativeName(list(dict.fromkeys(nomes))), critical=False)
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
            .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
            .sign(chave, hashes.SHA256()))
    os.makedirs(PASTA_CERT, exist_ok=True)
    with open(CHAVE, "wb") as f:
        f.write(chave.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL,
                                    serialization.NoEncryption()))
    os.chmod(CHAVE, 0o600)
    with open(CERT, "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))
    print(f"Certificado autoassinado gerado para: {', '.join(HOSTS)} (valido por 825 dias)", flush=True)


class Redirecionar(BaseHTTPRequestHandler):
    def _ir(self):
        host = (self.headers.get("Host") or HOSTS[0]).split(":")[0]
        self.send_response(301)
        self.send_header("Location", f"https://{host}:{PORTA_PUBLICA}{self.path}")
        self.send_header("Content-Length", "0")
        self.end_headers()

    do_GET = do_HEAD = do_POST = _ir

    def log_message(self, *args):
        pass


if __name__ == "__main__":
    if not (os.path.exists(CERT) and os.path.exists(CHAVE)):
        gerar_certificado()
    else:
        print("Usando o certificado existente em", PASTA_CERT, flush=True)
    if PORTA_HTTP:
        servidor = ThreadingHTTPServer(("0.0.0.0", PORTA_HTTP), Redirecionar)
        threading.Thread(target=servidor.serve_forever, daemon=True).start()
        print(f"HTTP na porta {PORTA_HTTP}: redirecionando para HTTPS na porta {PORTA_PUBLICA}", flush=True)
    print(f"Portal em HTTPS na porta {PORTA_HTTPS}", flush=True)
    uvicorn.run("main:app", host="0.0.0.0", port=PORTA_HTTPS, ssl_certfile=CERT, ssl_keyfile=CHAVE,
                proxy_headers=True, log_level="info")
